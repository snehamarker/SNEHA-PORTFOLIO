# Personal Portfolio Website
- `index.html`: semantic HTML structure and portfolio content.
- `style.css`: design, layouts, hover/focus states, and responsive media queries.
- `PROJECT_DESCRIPTION.txt`: description for the submission form.
- `screenshots/`: save desktop and mobile screenshots here.

Before submitting, replace the sample email and GitHub link in the Contact section, check all personal details, open `index.html` in Chrome/Edge, and capture desktop and mobile screenshots. Built with HTML5 and CSS3 only; no JavaScript, React, Bootstrap, backend, or database.
